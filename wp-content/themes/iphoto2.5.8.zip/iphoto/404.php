<?php get_header(); ?>
	<div id="container" style="margin-top:160px;text-align:center">
		<h1 style="font-size:196px;color:#666">404</h1>
		<p style="margin-bottom:50px">No photos at all, just go back --> <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></p>
	</div><!--end container-->
	<div class="clear"></div>
<?php get_footer(); ?>